v0.0.2 (02-04-2016)
===================

-  Automatically find pandoc executable.
-  Updated export formats.

v0.0.1 (01-02-2010)
===================

-  Initial release.
